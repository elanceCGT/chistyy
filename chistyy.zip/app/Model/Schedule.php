<?php
App::uses('AppModel', 'Model');
class Schedule extends AppModel{

}