<?php

App::uses('AppModel', 'Model');

/**
 * CakePHP Setting
 * @author Mukesh Sharma
 * @created Dec 20, 2014
 */
class Setting extends AppModel
{
	public $validate = array();
	
}
