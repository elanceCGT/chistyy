<?php

App::uses('AppModel', 'Model');

/**
 * CakePHP Sport
 * @author Mukesh Sharma
 * @created Dec 13, 2014
 */
class Sport extends AppModel
{
	
}
