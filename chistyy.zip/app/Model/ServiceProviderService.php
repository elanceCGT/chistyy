<?php
App::uses('AppModel', 'Model');
class ServiceProviderService extends AppModel{

	/*public $hasOne = array(
		'Service' => array('className' => 'Service', 'foreignKey' => 'servic_cd'), 
		'Category' => array('className' => 'Category', 'foreignKey' => 'servic_cat_cd'), 
		'Category' => array('className' => 'Category', 'foreignKey' => 'servic_subcat_cd')
	);*/
}